package com.songhaozhe.courseselection.adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;

import com.songhaozhe.courseselection.ui.fragment.FirstFragment;
import com.songhaozhe.courseselection.ui.fragment.SecondFragment;

import java.util.ArrayList;
import java.util.List;

// viewpager适配器，用于管理Fragment的显示和切换
public class ViewPagerAdapter extends FragmentPagerAdapter {

    private List<Fragment> mFragmentList = new ArrayList<>();
    private FragmentManager fm;

    public int getItemPosition(Object object) {

        if (object instanceof FirstFragment) {
            ((FirstFragment) object).update();
        } else if (object instanceof SecondFragment) {
            ((SecondFragment) object).updata();
        }
        return super.getItemPosition(object);
    }

    public void setFragments(List<Fragment> fragments) {
        if (this.mFragmentList != null) {
            FragmentTransaction ft = fm.beginTransaction();
            for (Fragment f : this.mFragmentList) {
                ft.remove(f);
            }
            ft.commit();
            ft = null;
            fm.executePendingTransactions();
        }
        this.mFragmentList = fragments;
        notifyDataSetChanged();
    }

    public ViewPagerAdapter(FragmentManager manager) {
        super(manager);
        this.fm = manager;
    }

    @Override
    public Fragment getItem(int position) {
        return mFragmentList.get(position);
    }

    @Override
    public int getCount() {
        return mFragmentList.size();
    }

    public void addFragment(Fragment fragment) {
        mFragmentList.add(fragment);
    }
}