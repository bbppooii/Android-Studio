package com.songhaozhe.courseselection.ui.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.songhaozhe.courseselection.MyApplication;
import com.songhaozhe.courseselection.R;
import com.songhaozhe.courseselection.adapter.StudentAdapter;
import com.songhaozhe.courseselection.db.StudentDao;
import com.songhaozhe.courseselection.entity.StudentInfo;
import com.songhaozhe.courseselection.ui.activity.ContainerActivity;
import com.songhaozhe.courseselection.ui.activity.StudentChangeActivity;

import java.util.List;

// BottomNavigationView对应的第三个Fragment
// 显示个人信息;从修改信息的界面返回ThirdFragment时，状态为onResume,重写onResume方法实现刷新数据。
public class ThirdFragment extends Fragment {

    private Context context = MyApplication.getInstance();
    private StudentDao student = new StudentDao(context);
    private List<StudentInfo> StudentList = student.getStudent(ContainerActivity.getStudentId());
    private RecyclerView recyclerView;
    private int studentId = ContainerActivity.getStudentId();

    public ThirdFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, final Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_third, container, false);
        //initCourse();
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        //StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL);
        LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        StudentAdapter adapter = new StudentAdapter(StudentList);
        recyclerView.setAdapter(adapter);
        DividerItemDecoration mDividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), layoutManager.getOrientation());
        recyclerView.addItemDecoration(mDividerItemDecoration);
        Button button = (Button) view.findViewById(R.id.click);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(context, StudentChangeActivity.class);
                intent.putExtra("id", studentId);
                startActivity(intent);
            }
        });
        return view;
    }

    public void onResume() {
        super.onResume();
        StudentList = student.getStudent(ContainerActivity.getStudentId());
        StudentAdapter adapter = new StudentAdapter(StudentList);
        recyclerView.setAdapter(adapter);
    }
}