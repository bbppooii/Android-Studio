package com.songhaozhe.courseselection.ui.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.songhaozhe.courseselection.EditCheck;
import com.songhaozhe.courseselection.MyApplication;
import com.songhaozhe.courseselection.R;
import com.songhaozhe.courseselection.db.MyDatabaseHelper;
import com.songhaozhe.courseselection.db.UserDao;

// 登录界面Activity
public class LoginActivity extends AppCompatActivity {

    private MyDatabaseHelper dbHelper;
    private EditText account;
    private EditText password;
    private Button login;
    private Button modifyPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        dbHelper = new MyDatabaseHelper(this);
        dbHelper.getWritableDatabase();
        account = (EditText) findViewById(R.id.account);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.login);
        modifyPwd = (Button) findViewById(R.id.modifyPwd);
        final UserDao user = new UserDao(this);
        // 点击登录，跳转到MainActivity,传入对应id
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id_str = account.getText().toString();
                // int id = Integer.parseInt(id_str);
                String passwd = password.getText().toString();
                if (id_str.isEmpty() && passwd.isEmpty()) {
                    showNormalDialog("请输入帐号(学号)或密码！");
                    return;
                }
                try {
                    Integer.parseInt(id_str);
                } catch (Exception e) {
                    showNormalDialog("帐号(学号)格式错误！");
                    return;
                }
                if (EditCheck.CheckInt(id_str, "账号", 00000, 99999)) {
                    writeDatabase(id_str, "123456");
                }
                if (!EditCheck.CheckInt(id_str, "账号", 00000, 99999)) {
                    showNormalDialog(EditCheck.getWarning());
                } else if (!EditCheck.CheckString(passwd, "密码", 20)) {
                    showNormalDialog(EditCheck.getWarning());
                } else if (user.check(Integer.parseInt(id_str), passwd)) {
                    // 账号匹配成功,进入MainActivity
                    Intent intent = new Intent(LoginActivity.this, ContainerActivity.class);
                    intent.putExtra("id", Integer.parseInt(id_str));
                    startActivity(intent);
                    finish();
                } else {

                    // 弹出错误提示框
                    String word = "账号或密码错误！";
                    showNormalDialog(word);
                }
            }
        });
        modifyPwd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, ModifyPasswdActivity.class);
                startActivity(intent);
            }
        });
    }

    private void showNormalDialog(String word) {
        final AlertDialog.Builder normalDialog = new AlertDialog.Builder(LoginActivity.this);
        normalDialog.setTitle("提示");
        normalDialog.setMessage(word);
        normalDialog.setPositiveButton("确定",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        normalDialog.setCancelable(true);
                    }
                });
        // 显示
        normalDialog.show();
    }

    public boolean writeDatabase(String username, String password) {
        Context context = MyApplication.getInstance();
        UserDao user = new UserDao(context);
        if (user.insertLog(Integer.parseInt(username), password)) {
            return true;
        } else
            return false;
    }
}